from aiogram.fsm.state import State, StatesGroup

class RegistrationStates(StatesGroup):
    waiting_for_name = State()
    waiting_for_phone = State()

class EditProfileStates(StatesGroup):
    waiting_for_name = State()
    waiting_for_phone = State()

